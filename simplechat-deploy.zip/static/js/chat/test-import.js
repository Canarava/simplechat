// Test file to verify the export works
import { loadUserSettings } from "./chat-layout.js";

console.log("Import successful, loadUserSettings is:", typeof loadUserSettings);
