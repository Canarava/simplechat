# semantic_kernel_plugins/__init__.py
"""
Custom Semantic Kernel plugins for simplechat application.

This package contains enhanced and custom plugins that extend the
standard Semantic Kernel functionality with application-specific features.
"""

__version__ = "0.228.004"
